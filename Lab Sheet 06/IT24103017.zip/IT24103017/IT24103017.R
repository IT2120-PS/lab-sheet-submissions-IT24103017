setwd("C:\\Users\\Nadeeth\\Desktop\\IT24103017")

# Exercise Q1
n <- 50
p <- 0.85

# i. Distribution
cat("X ~ Binomial(50, 0.85)\n")

# ii. P(X >= 47)
1 - pbinom(46, n, p)

# Exercise Q2
lambda <- 12

# i. Random variable
cat("X = number of calls received in one hour\n")

# ii. Distribution
cat("X ~ Poisson(12)\n")

# iii. P(X = 15)
dpois(15, lambda)