setwd("C:\\Users\\Nadeeth\\Desktop\\PS L7")

# Exercise 1: Uniform Distribution
prob_ex1 <- punif(25, min = 0, max = 40, lower.tail = TRUE) - punif(10, min = 0, max = 40, lower.tail = TRUE)
cat("Exercise 1 - Probability train arrives between 8:10 and 8:25:", prob_ex1, "\n\n")

# Exercise 2: Exponential Distribution
# Software update time (X ~ Exponential(λ = 1/3))
# P(X <= 2)
prob_ex2 <- pexp(2, rate = 1/3, lower.tail = TRUE)
cat("Exercise 2 - Probability update takes at most 2 hours:", prob_ex2, "\n\n")

# Exercise 3: Normal Distribution
# IQ scores (X ~ Normal(μ = 100, σ = 15))

# Part i: P(X > 130)
prob_ex3_i <- pnorm(130, mean = 100, sd = 15, lower.tail = FALSE)
cat("Exercise 3(i) - Probability IQ above 130:", prob_ex3_i, "\n")

# Part ii: 95th percentile (P(X <= x) = 0.95)
iq_95 <- qnorm(0.95, mean = 100, sd = 15, lower.tail = TRUE)
cat("Exercise 3(ii) - IQ score at 95th percentile:", iq_95, "\n")
