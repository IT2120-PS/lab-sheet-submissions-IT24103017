setwd("C:\\Users\\Nadeeth\\Desktop\\Lab 09")

# Exercise Question 1
# Part (i): Generate a random sample of size 25
set.seed(123)  # For reproducible results
baking_times <- rnorm(25, mean = 45, sd = 2)

# Part (ii): One-sample t-test
# H0: μ ≥ 46 vs H1: μ < 46
test_result <- t.test(baking_times, mu = 46, alternative = "less")

print(test_result)

# Extract test statistic, p-value, and confidence interval
test_statistic <- test_result$statistic
p_value <- test_result$p.value
conf_interval <- test_result$conf.int

cat("Test Statistic (t):", test_statistic, "\n")
cat("P-value:", p_value, "\n")
cat("95% Confidence Interval:", conf_interval, "\n")

# Conclusion
if (p_value < 0.05) {
  cat("Conclusion: Reject H0. The average baking time is significantly less than 46 minutes.")
} else {
  cat("Conclusion: Do not reject H0. There is no significant evidence that the average baking time is less than 46 minutes.")
}
