setwd("C:\\Users\\Nadeeth\\Desktop\\IT24103017")

data<-read.table("Exercise - LaptopsWeights.txt",header=TRUE)
weights <- data$Weight.kg.  # extract the column

# --- Step 2: Population mean and population standard deviation ---
pop_mean <- mean(weights)
pop_sd <- sd(weights)

cat("Population Mean:", pop_mean, "\n")
cat("Population Standard Deviation:", pop_sd, "\n")

# --- Step 3: Draw 25 random samples of size 6 (with replacement) ---
set.seed(123)  # reproducibility
sample_means <- numeric(25)
sample_sds <- numeric(25)

for(i in 1:25){
  sample_data <- sample(weights, size=6, replace=TRUE)
  sample_means[i] <- mean(sample_data)
  sample_sds[i] <- sd(sample_data)
}

cat("\nSample Means:\n")
print(sample_means)
cat("\nSample Standard Deviations:\n")
print(sample_sds)

# --- Step 4: Mean and SD of the 25 sample means ---
mean_sample_means <- mean(sample_means)
sd_sample_means <- sd(sample_means)

cat("\nMean of Sample Means:", mean_sample_means, "\n")
cat("Standard Deviation of Sample Means:", sd_sample_means, "\n")

# --- Step 5: Relationship ---
cat("\nObservation:\n")
cat("1. Mean of sample means ≈ Population mean.\n")
cat("2. SD of sample means < Population SD.\n")
cat("   (SD(sample means) ≈ Population SD / sqrt(sample size)).\n")